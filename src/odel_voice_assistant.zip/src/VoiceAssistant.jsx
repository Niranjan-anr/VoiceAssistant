import React, { useState, useEffect, useRef } from 'react';
import './App.css';
import startupSound from './startup.mp3';
import odelLogo from './odel-logo.jpg';
import odelAvatar from './A_2D_digital_illustration_features_a_friendly_robo.png'; // Updated avatar

const VoiceAssistant = () => {
  const [output, setOutput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const synthRef = useRef(window.speechSynthesis);
  const recognitionRef = useRef(null);
  const wakeListenerRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(() => {
    const start = () => {
      if (audioRef.current) audioRef.current.play();
      const intro = new SpeechSynthesisUtterance("Hello! This is Odel. Ready to assist you.");
      intro.lang = 'en-IN';
      intro.rate = 0.85;
      synthRef.current.speak(intro);
      initWakeWordDetection();
      window.removeEventListener('click', start); // clean up
    };

    window.addEventListener('click', start);
  }, []);

  const speak = (text) => {
    synthRef.current.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'en-IN';
    utter.rate = 0.9;
    synthRef.current.speak(utter);
  };

  const controlLight = async (state) => {
    await fetch("https://iotx0-f34a3-default-rtdb.firebaseio.com/light.json", {
      method: "PUT",
      body: state,
    });
  };

  const getWikipediaAnswer = async (query) => {
    const title = encodeURIComponent(query);
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${title}`);
    const data = await res.json();
    return data.extract || "No summary available.";
  };

  const getDuckDuckAnswer = async (query) => {
    const res = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json`);
    const data = await res.json();
    return data.AbstractText || data.Answer || data.Definition || "I couldn't find a good answer.";
  };

  const getJoke = async () => {
    const res = await fetch("https://official-joke-api.appspot.com/random_joke");
    const data = await res.json();
    return `${data.setup} ... ${data.punchline}`;
  };

  const getDefinition = async (word) => {
    const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
    const data = await res.json();
    return data[0]?.meanings[0]?.definitions[0]?.definition || "No definition found.";
  };

  const getWeather = async () => {
    const res = await fetch("https://api.open-meteo.com/v1/forecast?latitude=12.97&longitude=77.59&current_weather=true");
    const data = await res.json();
    return `The current temperature is ${data.current_weather.temperature}°C.`;
  };

  const startListening = () => {
    console.log("Speech Recognition starting...");
    if (!recognitionRef.current) {
      recognitionRef.current = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
      recognitionRef.current.lang = 'en-IN';
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onresult = async (event) => {
        const query = event.results[event.results.length - 1][0].transcript.toLowerCase();
        setOutput(`🎙️ You said: "${query}"`);
        synthRef.current.cancel();

        if (query.includes("turn on the light")) {
          await controlLight(1);
          speak("Light turned on.");
        } else if (query.includes("turn off the light")) {
          await controlLight(0);
          speak("Light turned off.");
        } else if (query.includes("joke")) {
          const joke = await getJoke();
          speak(joke);
        } else if (query.includes("weather")) {
          const weather = await getWeather();
          speak(weather);
        } else if (query.includes("define")) {
          const word = query.replace("define", "").trim();
          const meaning = await getDefinition(word);
          speak(`Definition of ${word}: ${meaning}`);
        } else {
          let answer = await getDuckDuckAnswer(query);
          if (!answer || answer.length < 5) {
            answer = await getWikipediaAnswer(query);
          }
          speak(answer);
        }

        setIsListening(false);
        initWakeWordDetection();
      };

      recognitionRef.current.onerror = (e) => {
        console.error("Recognition error:", e.error);
        speak("Sorry, I didn't catch that.");
        setIsListening(false);
        initWakeWordDetection();
      };
    }

    setIsListening(true);
    recognitionRef.current.start();
  };

  const initWakeWordDetection = () => {
    console.log("Wake word listening started...");
    if (!wakeListenerRef.current) {
      wakeListenerRef.current = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
      wakeListenerRef.current.lang = 'en-IN';
      wakeListenerRef.current.continuous = true;
      wakeListenerRef.current.interimResults = true;

      wakeListenerRef.current.onresult = (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase();
        if (transcript.includes("hey odel")) {
          console.log("Wake word detected!");
          wakeListenerRef.current.stop();
          startListening();
        }
      };

      wakeListenerRef.current.onerror = (e) => {
        console.error("Wake word listener error:", e.error);
        setTimeout(initWakeWordDetection, 3000);
      };

      wakeListenerRef.current.start();
    }
  };

  return (
    <div className={`container ${isListening ? 'listening' : ''}`}>
      <audio ref={audioRef} src={startupSound} preload="auto" />
      <img src={odelLogo} alt="Odel Logo" className="odel-logo" />
      <img src={odelAvatar} alt="Odel Avatar" className="odel-avatar" />
      <div className="intro-animation">🤖 Odel is online</div>
      <h1 className="title">🧠 Odel Voice Assistant</h1>
      <button className="listen-button" onClick={startListening}>🎤 Talk to Odel</button>
      {isListening && <div className="wave-animation">🎧 Listening...</div>}
      <p className="output-text">{output}</p>
    </div>
  );
};

export default VoiceAssistant;
